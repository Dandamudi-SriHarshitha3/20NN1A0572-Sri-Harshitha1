// Limits count for querying documents
export const NOTIFICATIONS_LIMIT = 10;
export const MESSAGES_LIMIT = 10;
export const LIKES_LIMIT = 10;
export const FEED_LIMIT = 10;
export const COMMENTS_LIMIT = 10;
export const USERS_LIMIT = 10;
export const POST_LIMIT = 10;
export const BOOKMARKS_LIMIT = 10;