export { default as Bio } from './Bio';
export { default as Bookmarks } from './Bookmarks';
export { default as EditInfo } from './EditInfo';
export { default as Followers } from './Followers';
export { default as Following } from './Following';
export { default as Info } from './Info';
export { default as Posts } from './Posts';

