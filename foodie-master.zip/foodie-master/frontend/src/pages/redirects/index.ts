export { default as SocialAuthFailed } from './SocialAuthFailed';
